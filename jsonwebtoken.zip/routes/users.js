var express = require('express');
var router = express.Router();
const db = require('../db.js');
const cryptography  = require('../cryptography');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/login', function(req, res, next) {
  
  res.render('login',{msg:''})
});

router.post('/login', async function(req,res, next){
  
  let userinfo = await db.readUserInfo(req.body.name);
  //is a user exists?
  if (!userinfo) {
    res.render('login',{msg:'Incorrect user name or password!'});
  } else if(await cryptography.validatePassword(userinfo.userpass, req.body.password)) {
    res.json(req.body);
  } else {
    res.render('login',{msg:'Incorrect user name or password!'});
  }
  //is a password correct?

  /** body.name;  body.password */

  res.json(req.body);
})


router.get('/register', async (req, res, next)=>{

  res.render('register',{msg:''});
})

router.post('/register',async (req, res, next)=>{
  let hashed = await cryptography.hashPassword(req.body.password);

  if( ! await db.addNewUser(req.body.name, hashed)) {
     res.render('register',{msg:'User exists!'});
  } else {
    res.json(req.body);
  }
})

module.exports = router;
