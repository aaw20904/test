var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
require('dotenv').config()



const jwtValidator = async (req, res, next) => {
  if (!req.cookies.jwt) {
      req.userPersonalInfo = false;
      next();
  } 
    let token = req.cookies.jwt;
    //verify:
    await new Promise((resolve, reject) => {
        jwt.verify(token, process.env.SECRET_KEY, function (err, decoded) {
            if (err) {
              req.userPersonalInfo = false;
              resolve();
            } else {
              req.userPersonalInfo = decoded;
              resolve();
            }
        });
    });
    ///is a userinfo exists:
   next();
 
}



router.use(jwtValidator);
/* GET home page. */
router.get('/', function(req, res, next) {
  if(! req.userPersonalInfo){
    res.redirect('/users/login');
  } else {
      res.render('index', { title: 'Express', usr: req.userPersonalInfo.name });
  }

});

module.exports = router;
