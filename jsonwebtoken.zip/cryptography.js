const bcrypt = require('bcrypt');

class Cryptography {

     async hashPassword (password) {
        return await new Promise((resolve, reject) => {
            bcrypt.hash(password, 12, function(err, hash) {
                    if (err) {
                        reject(err)
                    } else {
                        resolve(hash);
                    }
                  // Store hash in your password DB.
            });
        });
     }

     async validatePassword (hashed, plain) {
        return await new Promise((resolve, reject) => {
            bcrypt.compare(plain, hashed, function(err, result) {
               if (err) {
                reject(err);
               } else {
                resolve(result);
               }
            });
        });
     }

}



let cryptography = new Cryptography();



module.exports = cryptography;