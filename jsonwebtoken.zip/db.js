const mysql = require('mysql2');
let db = null;

class MyDb {
    constructor(opts={
                    host     : 'localhost',
                    user     : 'root',
                    password : '65535258',
                    database : 'example'
                }){
        this.db = mysql.createConnection(opts);
    }
  /**try connect */
    async connectToDb() {
      await new Promise((resolve, reject) => {
          this.db.connect( (err)=>{
            if (err) {
                reject (err);
            } else {
                console.log('Connected !')
                resolve ();
            }
          })
      });

 
      /**create a databse if not exists */
      await new Promise((resolve, reject) => {
          this.db.query( "CREATE TABLE IF NOT EXISTS `example`.`users` ("+
            " `userid` INT NOT NULL AUTO_INCREMENT,"+
            "`username` VARCHAR(16) NULL,"+
            "`userpass` BLOB NULL,"+
            "PRIMARY KEY (`userid`),"+
            "UNIQUE INDEX `username_UNIQUE` (`username` ASC) VISIBLE);", (err, rows)=>{
            if(err){
                reject(err);
            } else{
                resolve(rows);
            }
        })
      });


    }

    async addNewUser (name , password) {
      return  await new Promise((resolve, reject) => {
            this.db.query("INSERT INTO users (username, userpass) VALUES (? , ?)",[name,password],(err, rows)=>{
                if(err){
                    if(err.errno == 1062){
                        //when duplicate username
                        resolve(false);
                        return;
                    }
                    reject(err);
                } else {
                    resolve(rows);
                }
            })
        });
    }

    async readUserInfo (name) {
      return  await new Promise((resolve, reject) => {
            this.db.query(`SELECT * FROM users WHERE username="${name}";`,(err, rows)=>{
                if(err){
                    reject(err);
                } else {
                    if(rows.length == 0) {
                        //when a user hasn`t been found
                        resolve(false)
                    } else {
                           resolve(rows);
                    }
                 
                }
            })
        });
    }

     async removeUser (name) {
      return  await new Promise((resolve, reject) => {
            this.db.query(`DELETE * FROM users WHERE username="${name}";`,(err, rows)=>{
                if(err){
                    reject(err);
                } else {
                     resolve(rows);
                }
            })
        });
    }


    async closeConnection() {
        await new Promise((resolve, reject) => {
            this.db.end(err=>{
                if(err){
                    reject(err);
                } else {
                     
                     resolve()
                }
               
            })
        });
    }



    /** */
}


 go();

async function go () {
      db = new MyDb();
      await db.connectToDb();
}

module.exports=db
